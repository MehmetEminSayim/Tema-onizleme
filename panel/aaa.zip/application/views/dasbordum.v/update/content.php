Boş bir content e sahibiz

