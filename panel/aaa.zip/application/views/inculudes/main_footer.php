<div class="wrap p-t-0">
    <footer class="app-footer">
        <div class="clearfix">
            <ul class="footer-menu pull-right">

            </ul>
            <div class="copyright pull-left">EDİTÖR MEHMET EMİN SAYIM   &copy; <?php echo date("Y");?>


            </div>
        </div>
    </footer>
</div>
