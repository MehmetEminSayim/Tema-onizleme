

<script src="<?php echo base_url("assest"); ?>/assets/js/news.js"></script>
