<?php
echo $this->basic_model->getTable('contracts',['id' => 4],true)->contract_description;